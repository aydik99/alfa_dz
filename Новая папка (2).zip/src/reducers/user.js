const initialState = {
	name: 'Aydemir',
	surname: 'Aliev',
	age: 23
}

export default function userState(state = initialState)
{
	return state; 
}